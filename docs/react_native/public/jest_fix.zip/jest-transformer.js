const config = {
    babelrc: false,
    presets: [
      [
        "react-native",
        {
          modules: true
        }
      ],
    ],
    plugins: [
      "transform-es2015-modules-commonjs"
    ]
  };
  module.exports = require("babel-jest").createTransformer(config);
  