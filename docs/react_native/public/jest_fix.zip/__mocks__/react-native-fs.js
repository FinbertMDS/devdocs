module.export = {
    mkdir: jest.fn(),
    moveFile: jest.fn(),
    copyFile: jest.fn(),
}
  